import math
import time
import numpy as np
import pickle
import pandas
from itertools import chain
from typing import Dict, List
from tensorflow.keras.utils import Sequence
from dataclasses import dataclass

from pandas import DataFrame

#from utils.log_hepler import logger, add_log_file, remove_log_file
from utils.path_helper import ROOT_DIR
from utils.word2vec_hepler import PAD_WORD_ID


@dataclass
class BaseConfig(object):
    num_epochs: int
    batch_size: int
    learning_rate: float
    l2_regularization: float
    learning_rate_decay: float
    device: str



def get_review_dict():
    user_review = pickle.load(open(ROOT_DIR.joinpath("data/user_review_word_idx.p"), "rb"))
    item_review = pickle.load(open(ROOT_DIR.joinpath("data/item_review_word_idx.p"), "rb"))
    return user_review, item_review

def get_meta_dict():
    user_meta = pickle.load(open(ROOT_DIR.joinpath("data/user_meta_dict.p"), "rb"))
    item_meta = pickle.load(open(ROOT_DIR.joinpath("data/item_meta_dict.p"), "rb"))
    return user_meta, item_meta


def load_reviews(review: Dict[str, DataFrame], query_id: str, exclude_id: str, max_length) -> List[int]:
    """
    1. Load review from review dict by userID/itemID
    2. Exclude unknown review by itemID/userID.
    3. Pad review text to max_length

    E.g. get all reviews written by user1 except itemA
         when we predict the rating of itemA marked by user1.

        DataFrame for user1:

            | itemID | review |
            | itemA  | 0,1,2  |
            | itemB  | 1,2,3  |
            | itemC  | 2,3,4  |

        query_id: user1
        exclude_id: itemA
        max_length: 8

        output = [1, 2, 3, 2, 3, 4, PAD_WORD_ID, PAD_WORD_ID]
    """

    reviews = review[query_id]
    key = "userID" if "userID" in reviews.columns else "itemID"
    reviews = reviews["review"][reviews[key] != exclude_id].to_list()
    reviews = list(chain.from_iterable(reviews))

    if len(reviews) >= max_length:
        reviews = reviews[:max_length]
    else:
        reviews = reviews + [PAD_WORD_ID] * (max_length - len(reviews))
    return reviews



class ReviewDataLoader(Sequence):
    def __init__(self, data: DataFrame, batch_size: int, shuffle: bool, config: BaseConfig):
        self.batch_size = batch_size
        self.shuffle = shuffle
        review_by_user, review_by_item = get_review_dict()
        meta_by_user, meta_by_item = get_meta_dict()

        self.user_reviews = [load_reviews(review_by_user, userID, itemID, config.max_review_length) for userID, itemID in zip(data["userID"], data["itemID"])]
        self.user_reviews = np.stack(self.user_reviews)

        self.user_metas = [meta_by_user[userID] for userID in list(data["userID"])]
        self.user_metas = np.stack(self.user_metas)

        self.item_reviews = [load_reviews(review_by_item, itemID, userID, config.max_review_length) for userID, itemID in zip(data["userID"], data["itemID"])]
        self.item_reviews = np.stack(self.item_reviews)

        self.item_metas = [meta_by_item[userID] for userID in list(data["userID"])]
        self.item_metas = np.stack(self.user_metas)

        self.ratings = np.array(data['rating'])

    def __len__(self):
        return math.ceil(len(self.ratings) / self.batch_size)

    def __getitem__(self, idx):
        indices = self.indices[idx*self.batch_size:(idx+1)*self.batch_size]
        batch_user_reviews = self.user_reviews[indices]
        batch_user_metas = self.user_metas[indices]
        batch_item_reviews = self.item_reviews[indices]
        batch_item_metas = self.item_metas[indices]
        return batch_user_reviews, batch_user_metas, batch_item_reviews, batch_item_metas

    def on_epoch_end(self):
        self.indices = np.arange(len(self.ratings))
        if self.shuffle == True:
            np.random.shuffle(self.indices)


if __name__ == "__main__":
    from utils.data_reader import get_train_dev_test_data
    train_data, dev_data, test_data = get_train_dev_test_data()


    config = BaseConfig(
        max_review_length=2048,  # Make sure this value is smaller than max_length in data_reader.py
    )
    train_dataloader = ReviewDataLoader(train_data, batch_size = 16, shuffle=True)
    valid_dataloader = ReviewDataLoader(dev_data, batch_size = 16, shuffle=False)


    