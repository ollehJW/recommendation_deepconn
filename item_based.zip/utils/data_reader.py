import pickle
from typing import Set, List, Dict
import re
import json
import itertools

import pandas
from pandas import DataFrame
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MultiLabelBinarizer

from utils.log_helper import logger
from utils.path_helper import ROOT_DIR
from utils.word2vec_helper import review2wid, PAD_WORD, get_word_vec

def get_all_data(path="data/reviews.json") -> DataFrame:
    return pandas.read_json(ROOT_DIR.joinpath(path), lines=True)


def get_train_dev_test_data(path="data/reviews.json") -> (DataFrame, DataFrame):
    all_data = get_all_data(path)
    train, test = train_test_split(all_data, test_size=0.2, random_state=42)
    return train, dev, test


def get_stop_words(path="data/stopwords.txt") -> Set[str]:
    with open(ROOT_DIR.joinpath(path)) as f:
        return set(f.read().splitlines())


def get_punctuations(path="data/punctuations.txt") -> Set[str]:
    with open(ROOT_DIR.joinpath(path)) as f:
        return set(f.read().splitlines())


def get_hotel_price(text):
    if len(str(text).split('hotel_price')) > 1:
        price = re.sub(r"[^0-9]", "",str(text).split('hotel_price')[1].split('hotel_add')[0])
        if len(price) > 0:
            return float(price)
        else:
            return 0
    else:
        return 0

def get_hotel_rating(text):
    if len(str(text).split("hotel_rating': ")) > 1:
        rating = str(text).split("hotel_rating': ")[1].split(", 'hot")[0]
        if len(rating) > 0:
            return float(rating)
        else:
            return 0
    else:
        return 0    

def get_hotel_rank(text):
    if len(str(text).split("hotel_rank': ")) > 1:
        rank = str(text).split("hotel_rank': ")[1].split(", 'hot")[0]
        if len(rank) > 0:
            return float(rank)
        else:
            return 0
    else:
        return 0 

def get_hotel_review_num(text):
    if len(str(text).split("hotel_review_num': ")) > 1:
        num = re.sub(r"[^0-9]", "",str(text).split("hotel_review_num': ")[1].split(", 'Each")[0])
        if len(num) > 0:
            return float(num)
        else:
            return 0
    else:
        return 0 

def flatten_hotel_dict(text):
    if pandas.isna(text):
        return []
    else:
        text1 = str(text).replace("'", '"')
        text1 = text1.replace('" ', "' ")
        text1 = text1.replace('"s ', "'s ")
        text1 = text1.replace("None: None", '"Room types": ["None", "None"]')
        text1 = json.loads(text1)
        text1 = list(itertools.chain(*list(text1.values())))
        return text1




def process_raw_data(in_path="data/Hotel_based_dataset.csv", out_path="data/reviews.json"):
    """
    Read raw data and remove useless columns and clear review text.
    Then save the result to file system.
    """

    logger.info("reading raw data...")
    df = pandas.read_csv(ROOT_DIR.joinpath(in_path))
    df_review = df[["User_ID", "Hotel_ID", "clean_review", "review_rating"]]
    df_review.columns = ["userID", "itemID", "review", "rating"]

    df_user_meta = df[["User_ID", 'User_contributions_num', 'User_helpful_votes', 'trip_type', 'Review_helpful_votes']]
    df_user_meta.columns =["userID", 'User_contributions_num', 'User_helpful_votes', 'trip_type', 'Review_helpful_votes']
    df_user_meta = df_user_meta.drop_duplicates(['userID'], keep = 'first').reset_index(drop = True)
    df_user_meta['trip_type'][pandas.isna(df_user_meta['trip_type'])] = "Unknown"
    df_user_meta['User_contributions_num'][pandas.isna(df_user_meta['User_contributions_num'])] = 0
    df_user_meta['User_helpful_votes'][pandas.isna(df_user_meta['User_helpful_votes'])] = 0
    df_user_meta['Review_helpful_votes'][pandas.isna(df_user_meta['Review_helpful_votes'])] = 0
    df_user_meta = pandas.get_dummies(df_user_meta, columns = ['trip_type'], dtype = 'float')

    df_item_meta = df[["Hotel_ID", 'hotel_basic_dict', 'hotel_amenities_dict']]
    df_item_meta.columns = ["itemID", 'hotel_basic_dict', 'hotel_amenities_dict']
    df_item_meta = df_item_meta.drop_duplicates(['itemID'], keep = 'first').reset_index(drop = True)
    df_item_meta['hotel_price'] = df_item_meta['hotel_basic_dict'].map(get_hotel_price)
    df_item_meta['hotel_rating'] = df_item_meta['hotel_basic_dict'].map(get_hotel_rating)
    df_item_meta['hotel_rank'] = df_item_meta['hotel_basic_dict'].map(get_hotel_rank)
    df_item_meta['hotel_review_num'] = df_item_meta['hotel_basic_dict'].map(get_hotel_review_num)
    del df_item_meta['hotel_basic_dict']
    hotel_feature_tokens = df_item_meta['hotel_amenities_dict'].map(flatten_hotel_dict)
    mlb = MultiLabelBinarizer()
    hotel_feature_df = pandas.DataFrame(mlb.fit_transform(hotel_feature_tokens),
                   columns=mlb.classes_,
                   index=df_item_meta['itemID'])
    hotel_feature_df = hotel_feature_df.reset_index(drop = False)
    hotel_feature_df = hotel_feature_df.loc[:, hotel_feature_df.sum() > 20]
    del hotel_feature_df['']
    del df_item_meta['hotel_amenities_dict']
    df_item_meta = pandas.merge(df_item_meta, hotel_feature_df, on = 'itemID')

    df_review.to_json(ROOT_DIR.joinpath(out_path), orient="records", lines=True)
    df_user_meta.to_json(ROOT_DIR.joinpath("data/user_meta.json"), orient="records", lines=True)
    df_item_meta.to_json(ROOT_DIR.joinpath("data/item_meta.json"), orient="records", lines=True)
    logger.info("Processed data saved.")


def get_reviews_in_idx(data: DataFrame, word_vec) -> (Dict[str, DataFrame], Dict[str, DataFrame]):
    """
    1. Group review by user and item.
    2. Convert word into word idx.
    :return The dictionary from userID/itemID to review text in word idx with itemID/userID.
    """

    data["review"] = data["review"].apply(review2wid, args=[word_vec])
    review_by_user = dict(list(data[["itemID", "review"]].groupby(data["userID"])))
    review_by_item = dict(list(data[["userID", "review"]].groupby(data["itemID"])))

    return review_by_user, review_by_item


def get_review_dict():
    user_review = pickle.load(open(ROOT_DIR.joinpath("data/user_review_word_idx.p"), "rb"))
    item_review = pickle.load(open(ROOT_DIR.joinpath("data/item_review_word_idx.p"), "rb"))
    return user_review, item_review


if __name__ == "__main__":
    process_raw_data()

    train_data, dev_data, test_data = get_train_dev_test_data()
    known_data = pandas.concat([train_data, dev_data])

    word_vec = get_word_vec()

    user_review, item_review = get_reviews_in_idx(known_data, word_vec)
    pickle.dump(user_review, open(ROOT_DIR.joinpath("data/user_review_word_idx.p"), "wb"))
    pickle.dump(item_review, open(ROOT_DIR.joinpath("data/item_review_word_idx.p"), "wb"))