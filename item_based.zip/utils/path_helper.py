from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent

if __name__ == "__main__":
    print(ROOT_DIR)