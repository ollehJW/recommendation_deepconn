pip install gensim==3.8.3  
python -m pip install numpy==1.23.1
conda install -c conda-forge graphviz