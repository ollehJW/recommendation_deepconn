__author__ = "sanhan"
from dataclasses import dataclass
from typing import List

import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras.utils import plot_model

@dataclass
class BaseConfig(object):
    data_path:str
    user_path: str
    item_path: str
    user_meta_path: str
    item_meta_path: str
    embedding_path: str
    num_epochs: int
    batch_size: int
    learning_rate: float
    l2_regularization: float
    weight_decay: float
    user_meta_dim: int
    item_meta_dim: int

@dataclass
class DeepCoNNConfig(BaseConfig):
    max_review_length: int
    word_dim: int  # the dimension of word embedding
    kernel_widths: List[int]  # the window sizes of convolutional kernel
    kernel_deep: int  # the number of convolutional kernels
    latent_factors: int
    fm_k: int

class ConvMaxLayer(keras.Model):
    def __init__(self, config, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.convs = []
        self.maxs = []
        for lidx, width in enumerate(config.kernel_widths):
            self.convs.append(
                keras.layers.Conv1D(
                    filters=config.kernel_deep,
                    kernel_size=width,
                    strides=1,
                    name=f"conv_{lidx}"
                )
            )
            self.maxs.append(
                keras.layers.MaxPool1D(
                    pool_size=config.max_review_length - width + 1,
                    strides=1,
                    name=f"mp_{lidx}",
                    padding="same"
                )
            )
        self.activation = keras.layers.ReLU()
        self.full_connect = keras.layers.Dense(config.latent_factors, name="fc")
        self.flatten = keras.layers.Flatten(name="fltn")

    def call(self, inputs):
        outputs = []
        input_t = tf.transpose(inputs, perm=[0,2,1])
        for mpool, conv in zip(self.maxs, self.convs):
            out = keras.activations.relu(conv(input_t))
            max_out = mpool(out)
            flatten_out = self.flatten(max_out)
            outputs.append(flatten_out)
        conv_out = tf.concat(outputs, axis=1)
        latent = self.full_connect(conv_out)

        return latent

class FMLayer(keras.Model):
    def __init__(self, config, *args, **kwargs):
        super().__init__(*args, **kwargs)
        v_init = tf.random_normal_initializer()
        self.V = tf.Variable(
            initial_value=v_init(shape=(config.latent_factors*2, config.fm_k))
            ,trainable=True
        )
        self.linear = keras.layers.Dense(1)

    def call(self, x):
        s1_square = tf.reduce_sum(tf.pow(tf.matmul(x, self.V), 2), axis=1, keepdims=True)
        s2 = tf.reduce_sum(tf.matmul(tf.pow(x, 2), tf.pow(self.V, 2)), axis=1, keepdims=True)
        out_inter = 0.5 * (s1_square - s2)
        out_lin = self.linear(x)
        out = out_inter + out_lin
        return out

class FMLayerFinal(keras.Model):
    def __init__(self, config, *args, **kwargs):
        super().__init__(*args, **kwargs)
        v_init = tf.random_normal_initializer()
        self.V = tf.Variable(
            initial_value=v_init(shape=(2 * 1, 8))
            ,trainable=True
        )
        self.linear = keras.layers.Dense(1)


    def call(self, x):
        s1_square = tf.reduce_sum(tf.pow(tf.matmul(x, self.V), 2), axis=1, keepdims=True)
        s2 = tf.reduce_sum(tf.matmul(tf.pow(x, 2), tf.pow(self.V, 2)), axis=1, keepdims=True)
        out_inter = 0.5 * (s1_square - s2)
        out_lin = self.linear(x)
        out = out_inter + out_lin
        out = keras.activations.sigmoid(out)
        return out

class MetaLayer(keras.Model):
    def __init__(self, config, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.dense_1 = keras.layers.Dense(config.latent_factors*2, activation='relu') # change config.densedims = [] > for loop
        self.dense_2 = keras.layers.Dense(config.latent_factors, activation='relu')

    def call(self, inputs):
        output = self.dense_1(inputs)
        output = self.dense_2(output)
        return output

class DeepCoNN(keras.Model):
    def __init__(self, config, embedding_weight, *args, **kwargs):
        super().__init__(*args, **kwargs)
        emb_w = embedding_weight.vectors  #tf.random_normal_initializer()
        # self.embedding = keras.layers.Embedding(config.max_review_length, config.word_dim, 
        #                     embeddings_initializer=keras.initializers.Constant(
        #                         embedding_weight.vectors
        #                     ),
        #                     trainable=False)
        self.embedding = keras.layers.Embedding(emb_w.shape[0], emb_w.shape[1], 
                            embeddings_initializer=keras.initializers.Constant(
                                embedding_weight.vectors
                            ),
                            trainable=False)
        self.user_layer = ConvMaxLayer(config)
        self.item_layer = ConvMaxLayer(config)
        self.user_meta_layer = MetaLayer(config)
        self.item_meta_layer = MetaLayer(config)
        self.share_layer_users = FMLayer(config)
        self.share_layer_items = FMLayer(config)
        self.share_layer_all = FMLayerFinal(config)

    def call(self, inputs): #, user_meta, item_meta):
        user_review, item_review, user_meta, item_meta = inputs
        user_review = self.embedding(user_review)
        item_review = self.embedding(item_review)
        user_latent = self.user_layer(user_review)
        item_latent = self.item_layer(item_review)
        user_meta_latent = self.user_meta_layer(user_meta)
        item_meta_latent = self.item_meta_layer(item_meta)

        user_latent = tf.concat([user_latent, user_meta_latent], axis = 1)
        user_latent = self.share_layer_users(user_latent)
        item_latent = tf.concat([item_latent, item_meta_latent], axis = 1)
        item_latent = self.share_layer_items(item_latent)

        latent = tf.concat([user_latent, item_latent], axis = 1)
        predict = self.share_layer_all(latent)

        return predict

    def build(self, input_shapes):
        x = keras.layers.Input(input_shapes[0])
        y = keras.layers.Input(input_shapes[1])
        z = keras.layers.Input(input_shapes[2])
        w = keras.layers.Input(input_shapes[3])
        model = keras.Model(inputs=[x,y,z,w], outputs=self.call([x,y,z,w]), name='convMax')
        return model

if __name__ == "__main__":
    # the followings are stand alone test code
    import numpy as np
    from tensorflow.keras.losses import MeanSquaredError
    from tensorflow.keras.optimizers import Adam

    # set configurations
    config = DeepCoNNConfig(
        num_epochs=50,
        batch_size=16,
        learning_rate=1e-3,
        l2_regularization=1e-2,
        weight_decay=0.95,
        device="cpu",
        max_review_length=2048,  # Make sure this value is smaller than max_length in data_reader.py
        word_dim=300,
        kernel_widths=[2, 3, 5, 7],
        kernel_deep=100,
        latent_factors=300,
        fm_k=8
    )

    # debug model
    embedding_weights = np.random.random((2048, 300)) # change weights here
    model = DeepCoNN(config=config, embedding_weight=embedding_weights)
    model = model.build(input_shapes=((2048), (2048), (100), (100)))
    model.summary()
    plot_model(model, to_file="model.png", expand_nested=True, show_shapes=True)
    print("hold")

    # set real values
    a = np.random.random((1, 2048))
    b = np.random.random((1, 2048))
    c = np.random.random((1, 100))
    d = np.random.random((1, 100))
    out =model((a,b,c,d))
    print(out)

    ## training test-code 
    loss_fn = MeanSquaredError()
    optimizer = Adam() # <- set lr here
    train_dataset = [[a,b,c,d, 1]]
    epochs = 2
    for epoch in range(epochs):
        for step, (x,y,z,w, target) in enumerate(train_dataset):
            with tf.GradientTape() as tape:
                logits = model((x,y,z,w), training=True)
                loss = loss_fn(target, logits)
            # backpropagation
            grads = tape.gradient(loss, model.trainable_weights)
            optimizer.apply_gradients(zip(grads, model.trainable_weights))
            print(f"{step}, {float(loss)}")